PaSE Week #3 Practise Project

**By:** Godstime Israel

**From**: CodeCoast

<hr>

## Instructions

Trainees are required to clone the already design web page and convert it to React App. They are to break the content in the index.html into smaller React Components.
